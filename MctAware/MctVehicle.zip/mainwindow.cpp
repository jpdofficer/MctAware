#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    /*mainLayout = new QGridLayout(); // create a GridLayout
    QWidget *centralWidget = new QWidget(); //create a widget
    centralWidget ->setLayout(mainLayout); //from the centralWidget set the layout to mainLayout
    setCentralWidget(centralWidget); //set the main window to centralwidget
    setWindowTitle("MctVehicle");
    setFixedSize(360,200);*/

    QFile file("mainwindow.ui");
    file.open(QFile::ReadOnly);









}

void MainWindow::createIPAddressLabel(void)
{
    /*ipLabel = new QLabel("Router IP Address:",this); //create a new QLabel for Router IP
    QFont labelFont ("Ariel",13);// Set the font to Ariel bold at 12
    ipLabel->setFont(labelFont); // set the font of the ipLabel
    ipLabel->setGeometry(4,0,0,0);
    ipLabel->setAlignment(Qt::AlignTop);
    mainLayout->addWidget(ipLabel); //add the ipLabel to the main Window
*/
}

void MainWindow::createIPAddressEntry(void)
{
    /*
    IpEdit = new QLineEdit(); // create a new Line edit with default ip address
    IpEdit->setText("192.168.0.1");
    IpEdit->setGeometry(2,1,0,0);
    IpEdit->setAlignment(Qt::AlignTop);
    mainLayout->addWidget(IpEdit); //add the IpEdit to the main window
 */
}


void MainWindow::createRouterButton(void)
{
    /*routerButton = new QPushButton("Select router CSV",this);
    mainLayout->addWidget(routerButton,5,0,1, Qt::AlignCenter);
    connect(routerButton, &QPushButton::clicked, this, &MainWindow::handleRouterButtonClick);
*/

}

void MainWindow::handleRouterButtonClick()
{
    dialog->getOpenFileName();
}


MainWindow::~MainWindow()
{
    delete ui;
}

