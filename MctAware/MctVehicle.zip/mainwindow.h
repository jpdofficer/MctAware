#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGridLayout>
#include<QLabel>
#include<QLineEdit>
#include<QFont>
#include<QPushButton>
#include<QFileDialog>
#include <QFile>


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    void createIPAddressLabel(void);
    void createIPAddressEntry(void);
    void createRouterButton(void);
    ~MainWindow();


private slots:
    void handleRouterButtonClick();

private:
    Ui::MainWindow *ui;


    QGridLayout *mainLayout;
    QLabel *ipLabel;
    QLineEdit *IpEdit;
    QPushButton *routerButton;
    QFileDialog *dialog;

};
#endif // MAINWINDOW_H
